# MPI Teks Negosiasi — SMK Negeri 5 Kolaka Utara

Media Pembelajaran Interaktif Bahasa Indonesia Kelas X / Fase E, materi **Teks Negosiasi** (fokus dialog).

## Fitur
- Menu utama dan materi dialog interaktif.
- Contoh struktur teks negosiasi.
- Simulasi tawar-menawar dengan umpan balik otomatis.
- Aktivitas berpikir kritis.
- Kuis tiga soal, termasuk aktivitas mencocokkan dialog dan struktur.
- Skor otomatis selama sesi browser aktif.
- Dapat dibuka tanpa internet; tidak membutuhkan instalasi atau server.

## Cara menerbitkan di GitHub Pages
1. Buat repository baru di GitHub, misalnya `mpi-teks-negosiasi`.
2. Unggah **isi folder ini** ke direktori utama repository. Pastikan `index.html` berada langsung di root, bukan di dalam subfolder.
3. Buka **Settings → Pages** pada repository.
4. Di bagian **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/(root)`, lalu klik **Save**.
6. Tunggu proses publikasi selesai. URL situs biasanya berbentuk `https://NAMA-AKUN.github.io/NAMA-REPOSITORY/`.

Jika repository dibuat dengan nama `NAMA-AKUN.github.io`, URL umumnya berbentuk `https://NAMA-AKUN.github.io/`.

## Catatan
- Situs GitHub Pages dapat diakses publik. Jangan unggah data pribadi siswa.
- Skor dan status aktivitas disimpan sementara di memori halaman, bukan di server; memuat ulang halaman akan memulai sesi baru.
- Seluruh HTML, CSS, dan JavaScript sudah berada di `index.html`. Tidak ada aset eksternal yang wajib diunduh.
